-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2023 at 09:05 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lbms`
--

-- --------------------------------------------------------

--
-- Table structure for table `books_details`
--

CREATE TABLE `books_details` (
  `Book_id` int(11) NOT NULL,
  `book_name` varchar(100) DEFAULT NULL,
  `Author` varchar(100) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books_details`
--

INSERT INTO `books_details` (`Book_id`, `book_name`, `Author`, `Quantity`) VALUES
(1, 'Java', 'Sumit Arora', 4),
(2, 'HTML', 'Tim Berners-Lee', 3),
(3, 'Maths', 'R.S Agrwal', 4),
(4, 'Maths', 'S k das', 5);

-- --------------------------------------------------------

--
-- Table structure for table `issue_book_detail`
--

CREATE TABLE `issue_book_detail` (
  `id` int(11) NOT NULL,
  `book_id` int(11) DEFAULT NULL,
  `book_name` varchar(100) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `student_name` varchar(100) DEFAULT NULL,
  `issued_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `issue_book_detail`
--

INSERT INTO `issue_book_detail` (`id`, `book_id`, `book_name`, `student_id`, `student_name`, `issued_date`, `due_date`, `status`) VALUES
(1, 1, 'Java', 1, 'Ayush', '2023-01-20', '2023-01-23', 'Returned'),
(2, 2, 'HTML', 2, 'Dipti Singh', '2023-01-21', '2023-01-23', 'Returned'),
(3, 2, 'HTML', 2, 'Dipti Singh', '2023-01-21', '2023-01-22', 'pending'),
(4, 1, 'Java', 1, 'Ayush', '2023-01-15', '2023-01-20', 'pending'),
(5, 3, 'Maths', 1, 'Ayush', '2023-01-24', '2023-01-27', 'pending'),
(6, 4, 'Maths', 3, 'Mani', '2023-02-06', '2023-02-10', 'Returned');

-- --------------------------------------------------------

--
-- Table structure for table `student_details`
--

CREATE TABLE `student_details` (
  `student_id` int(11) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Course` varchar(100) DEFAULT NULL,
  `Semester` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_details`
--

INSERT INTO `student_details` (`student_id`, `Name`, `Course`, `Semester`) VALUES
(1, 'Ayush', 'BCA', 'Third'),
(2, 'Dipti Singh', 'MBA', 'First '),
(3, 'Mani', 'BCA', 'Fifth');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Id` int(11) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `Contactno` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Id`, `Name`, `password`, `email`, `Contactno`) VALUES
(1, 'abhi', 'abhi@123', 'abhi@gmail.com', '9211420786'),
(2, 'Anurag', 'Anu123', '790518976', '790518976'),
(3, 'harshita', 'harshi123', '9794982091', '9794982091');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books_details`
--
ALTER TABLE `books_details`
  ADD PRIMARY KEY (`Book_id`);

--
-- Indexes for table `issue_book_detail`
--
ALTER TABLE `issue_book_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_details`
--
ALTER TABLE `student_details`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books_details`
--
ALTER TABLE `books_details`
  MODIFY `Book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `issue_book_detail`
--
ALTER TABLE `issue_book_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `student_details`
--
ALTER TABLE `student_details`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
